import Cocoa

var str = "Hello, playground"

// Adding functions
func addingTwoNumbers(num1: Int, num2: Int) -> Int {
    var total = 0
    total = num1 + num2
    
    return total
}

var totalNumber = addingTwoNumbers(num1: 6, num2: 5)

print("6 + 3 = (\(addingTwoNumbers(num1: 6, num2: 5)))")
